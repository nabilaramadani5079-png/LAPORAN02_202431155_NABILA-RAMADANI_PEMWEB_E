const tidyBtn = document.getElementById("tidyBtn");
const messyBtn = document.getElementById("messyBtn");
const page = document.body;

// klik h3 → confirm hide
document.querySelectorAll("h3").forEach(h3 => {
  h3.addEventListener("click", () => {
    const answer = h3.nextElementSibling;
    const hide = confirm("Sembunyikan jawaban?");
    answer.style.display = hide ? "none" : "block";
  });
});

// Mode Rapi
tidyBtn.addEventListener("click", () => {
  page.classList.remove("messy");
  page.classList.add("tidy");
});

// Mode Berantakan
messyBtn.addEventListener("click", () => {
  page.classList.remove("tidy");
  page.classList.add("messy");
});
